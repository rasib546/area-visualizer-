# Area Imagination - Spatial Visualizer

A React app to visualize and compare area sizes against real-world spaces.

## Quick Start Deployment

### Step 1: Create a GitHub Account (if you don't have one)
1. Go to [github.com](https://github.com)
2. Click **Sign up** and create your account
3. Verify your email

### Step 2: Create a New Repository
1. Click the **+** icon in top right → **New repository**
2. Name it: `area-visualizer`
3. Choose **Public** (so Vercel can access it)
4. Click **Create repository**

### Step 3: Upload Files to GitHub
1. In your new repository, click **Add file** → **Upload files**
2. Download all files from this project folder on your computer
3. Drag and drop all files into GitHub's upload area
4. Make sure the folder structure is preserved:
   ```
   area-visualizer/
   ├── index.html
   ├── package.json
   ├── vite.config.js
   ├── tailwind.config.js
   ├── postcss.config.js
   ├── .gitignore
   ├── src/
   │   ├── main.jsx
   │   ├── App.jsx
   │   ├── index.css
   │   └── components/
   │       └── AreaVisualizer.jsx
   ```
5. Scroll down and click **Commit changes**

### Step 4: Deploy to Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click **Sign up** and choose **Continue with GitHub**
3. Authorize Vercel to access your GitHub
4. Click **Add New** → **Project**
5. Select your `area-visualizer` repository
6. Click **Import**
7. Vercel auto-detects it's a Vite project — just click **Deploy**
8. Wait 30-60 seconds...

### ✅ Done!
You'll get a URL like: `area-visualizer.vercel.app`

Share this link on your phone, it works perfectly!

---

## Optional: Add a Custom Domain

Once it's deployed on Vercel:
1. Buy a domain from [Namecheap](https://namecheap.com) or [Google Domains](https://domains.google.com) (~$12/year)
2. In Vercel project settings → **Domains**
3. Add your domain and follow DNS setup instructions
4. Done in 5 minutes

---

## Local Development (Optional)

If you want to run it locally on your computer:

```bash
# Install Node.js from nodejs.org

# Clone the repo and navigate to it
cd area-visualizer

# Install dependencies
npm install

# Run dev server
npm run dev

# Open http://localhost:3000 in your browser
```

---

## Tech Stack
- **React 18** — UI framework
- **Vite** — Build tool
- **Tailwind CSS** — Styling
- **Vercel** — Hosting

---

Questions? Message me. Happy hosting!
